#
# Copyright (C) 2013 - 2015 Satoru SATOH <ssato @ redhat.com>
# License: MIT
#
"""anyconfig globals.
"""
import anyconfig.init


AUTHOR = "Satoru SATOH <ssat@redhat.com>"
VERSION = "0.2.2"

LOGGER = anyconfig.init.LOGGER

# vim:sw=4:ts=4:et:
